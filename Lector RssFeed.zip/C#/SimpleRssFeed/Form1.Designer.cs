﻿namespace SimpleRssFeed
{
    partial class RssFeed
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._instructionLabel = new System.Windows.Forms.Label();
            this._urlText = new System.Windows.Forms.TextBox();
            this._goButton = new System.Windows.Forms.Button();
            this._feedTree = new System.Windows.Forms.TreeView();
            this._contentText = new System.Windows.Forms.TextBox();
            this._feedGrid = new System.Windows.Forms.PropertyGrid();
            this._rssOptionsCombo = new System.Windows.Forms.ComboBox();
            this._linkLabel = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // _instructionLabel
            // 
            this._instructionLabel.AutoSize = true;
            this._instructionLabel.Location = new System.Drawing.Point(25, 20);
            this._instructionLabel.Name = "_instructionLabel";
            this._instructionLabel.Size = new System.Drawing.Size(146, 13);
            this._instructionLabel.TabIndex = 0;
            this._instructionLabel.Text = "Ingresa la URL hacia el RSS:";
            // 
            // _urlText
            // 
            this._urlText.Location = new System.Drawing.Point(28, 36);
            this._urlText.Name = "_urlText";
            this._urlText.Size = new System.Drawing.Size(477, 20);
            this._urlText.TabIndex = 1;
            // 
            // _goButton
            // 
            this._goButton.Location = new System.Drawing.Point(721, 33);
            this._goButton.Name = "_goButton";
            this._goButton.Size = new System.Drawing.Size(50, 23);
            this._goButton.TabIndex = 2;
            this._goButton.Text = "&Ir";
            this._goButton.UseVisualStyleBackColor = true;
            this._goButton.Click += new System.EventHandler(this.OnLoadFeed);
            // 
            // _feedTree
            // 
            this._feedTree.Location = new System.Drawing.Point(28, 62);
            this._feedTree.Name = "_feedTree";
            this._feedTree.Size = new System.Drawing.Size(279, 274);
            this._feedTree.TabIndex = 3;
            this._feedTree.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.OnSelectNode);
            // 
            // _contentText
            // 
            this._contentText.AcceptsReturn = true;
            this._contentText.Location = new System.Drawing.Point(313, 87);
            this._contentText.Multiline = true;
            this._contentText.Name = "_contentText";
            this._contentText.Size = new System.Drawing.Size(458, 473);
            this._contentText.TabIndex = 4;
            // 
            // _feedGrid
            // 
            this._feedGrid.Location = new System.Drawing.Point(28, 342);
            this._feedGrid.Name = "_feedGrid";
            this._feedGrid.Size = new System.Drawing.Size(279, 218);
            this._feedGrid.TabIndex = 5;
            // 
            // _rssOptionsCombo
            // 
            this._rssOptionsCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._rssOptionsCombo.FormattingEnabled = true;
            this._rssOptionsCombo.Items.AddRange(new object[] {
            "RSS",
            "ATOM"});
            this._rssOptionsCombo.Location = new System.Drawing.Point(511, 35);
            this._rssOptionsCombo.Name = "_rssOptionsCombo";
            this._rssOptionsCombo.Size = new System.Drawing.Size(204, 21);
            this._rssOptionsCombo.TabIndex = 6;
            // 
            // _linkLabel
            // 
            this._linkLabel.Location = new System.Drawing.Point(313, 62);
            this._linkLabel.Name = "_linkLabel";
            this._linkLabel.Size = new System.Drawing.Size(458, 22);
            this._linkLabel.TabIndex = 7;
            this._linkLabel.TabStop = true;
            this._linkLabel.Text = "[Seleccione un elemento]";
            this._linkLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.OnLinkClicked);
            // 
            // RssFeed
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 572);
            this.Controls.Add(this._linkLabel);
            this.Controls.Add(this._rssOptionsCombo);
            this.Controls.Add(this._feedGrid);
            this.Controls.Add(this._contentText);
            this.Controls.Add(this._feedTree);
            this.Controls.Add(this._goButton);
            this.Controls.Add(this._urlText);
            this.Controls.Add(this._instructionLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(800, 600);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "RssFeed";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lector sencillo de RSS";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label _instructionLabel;
        private System.Windows.Forms.TextBox _urlText;
        private System.Windows.Forms.Button _goButton;
        private System.Windows.Forms.TreeView _feedTree;
        private System.Windows.Forms.TextBox _contentText;
        private System.Windows.Forms.PropertyGrid _feedGrid;
        private System.Windows.Forms.ComboBox _rssOptionsCombo;
        private System.Windows.Forms.LinkLabel _linkLabel;
    }
}

