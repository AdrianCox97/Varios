﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.ServiceModel.Syndication;
using System.Diagnostics;

namespace SimpleRssFeed
{
    public partial class RssFeed : Form
    {
        public RssFeed()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Crea un formateador dependiendo del tipo de feed seleccionado. 
        /// </summary>
        /// <remarks>El usuario puede seleccionar el tipo de feed, ya sea RSS o ATOM. Dependiendo
        /// del tipo es el formateador que regresamos. Este método actúa como una especie 
        /// de fábrica de clases. </remarks>
        /// <returns>Un formateador de tipo Rss20FeedFormatter si el tipo de feed está
        /// en RSS, o un Atom10FeedFormatter si lo está en ATOM. </returns>
        private SyndicationFeedFormatter CreateFormatter()
        {
            SyndicationFeedFormatter formatter = null;

            int index = _rssOptionsCombo.SelectedIndex;
            if (index == 0)
                formatter = new Rss20FeedFormatter();
            else if (index == 1)
                formatter = new Atom10FeedFormatter();
                
            return new Rss20FeedFormatter();
        }

        /// <summary>
        /// Carga el feed ingresado por el usuario (RSS o ATOM). 
        /// </summary>
        /// <remarks>
        /// El usuario ingresa la URL del feed en el campo de texto y selecciona el tipo de feed
        /// que desea emplear (RSS o ATOM). De dicha URL se crea un lector XML, el cual descarga
        /// el contenido del feed. Luego creamos el formateador llamando a CreateFormatter. Tras 
        /// esto, contamos ya con el feed, el cual contiene información general y que se muestra
        /// en el grid de propiedades. Cada elemento es cargado en el árbol como un nodo, el cual
        /// al seleccionarse cargará la información del mismo en el texto de contenido y en la 
        /// etiqueta de enlace. 
        /// </remarks>
        private void OnLoadFeed(object sender, EventArgs args)
        {
            try
            {
                // Vaciamos el contenido en primera instancia. 
                _contentText.Text = string.Empty;

                // Una pequeña comodidad: si el usuario no ingresa el protocolo http:// se lo
                // añadimos, para evitar que la URL esté mal formada. 
                if (!_urlText.Text.StartsWith("http://") && !_urlText.Text.StartsWith("https://"))
                    _urlText.Text = string.Format("http://{0}", _urlText.Text);

                // Creamos el formateador, el cual será RSS o ATOM, dependiendo de la opción
                // seleccionada por el usuario. 
                SyndicationFeedFormatter formatter = CreateFormatter();

                // Leemos el XML de la URL seleccionada...
                using (XmlReader reader = XmlReader.Create(_urlText.Text))
                {
                    // ...y le decimos al formateador que analice el XML del feed. 
                    formatter.ReadFrom(reader);
                }
                // Si la URL es inválida, recibiremos un UriFormatException. Si el XML 
                // descargado tiene algún contenido inválido, que no se ciña a la especificación
                // de RSS o de ATOM, entonces recibiremos un XmlException. 

                // Vaciamos el árbol y añadimos un nodo raíz. 
                _feedTree.Nodes.Clear();
                TreeNode rootNode = _feedTree.Nodes.Add(formatter.Feed.Title.Text);

                // Para cada elemento encontrado en el feed añadimos un nodo. Adjuntamos 
                // el objeto de dicho elemento a la propiedad Tag del nodo, para poder
                // referirnos a éste posteriormente (i.e. cuando se dispare el evento
                // NodeMouseClick). 
                foreach (SyndicationItem item in formatter.Feed.Items)
                {
                    TreeNode feedNode = rootNode.Nodes.Add(item.Title.Text);
                    feedNode.Tag = item;
                }

                // Añadimos al grid de propiedades alguna información sobre el feed, 
                // creando un objeto anónimo que contenga el título, lenguaje, 
                // descripción, fecha de última actualización y notas sobre derechos
                // de autor. 
                _feedGrid.SelectedObject = new {
                    Title = formatter.Feed.Title.Text,
                    Language = formatter.Feed.Language,
                    Description = formatter.Feed.Description.Text,
                    LastUpdatedTime = formatter.Feed.LastUpdatedTime.DateTime,
                    Copyright = formatter.Feed.Copyright
                };
            }
            catch (UriFormatException)
            {   // La url está mal formada o es inválida. 
                MessageBox.Show(this, "La URL provista es inválida. ", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _urlText.Focus();
                _urlText.SelectAll();
            }
            catch (XmlException ex)
            {   // El XML devuelto por el feed es inválido, seguramente la fuente tiene algún campo 
                // inválido. 
                MessageBox.Show(this, "El RSS está mal formado. Es posible que la fuente no siga la especificación RSS correcta. ", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _urlText.Focus();
                _urlText.SelectAll();
                _contentText.Text = ex.Message;
            }
            catch (Exception ex)
            {   // Cualquier otro error es atrapado aquí. 
                _contentText.Text = ex.ToString();
            }

            // Al terminar este método contamos ya con el árbol cargado. 
        }

        /// <summary>
        /// Coloca el contenido del nodo seleccionado en la caja de texto, junto con
        /// alguno de los datos más importantes, el resumen, y también modificamos el
        /// LinkLabel para que apunte hacia la URL del elemento. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void OnSelectNode(object sender, TreeNodeMouseClickEventArgs args)
        {
            SyndicationItem item = args.Node.Tag as SyndicationItem;
            if (item != null)
            {
                StringBuilder text = new StringBuilder()
                    .AppendFormat("Título: {0}\r\n", item.Title.Text)
                    .AppendFormat("Publicado: {0}\r\n", item.PublishDate.DateTime)
                    .AppendFormat("Actualizado: {0}\r\n", item.LastUpdatedTime.DateTime)
                    .AppendLine()
                    .AppendFormat(item.Summary.Text)
                    .AppendLine()
                    .AppendLine();
                if (item.Content != null)
                {
                    text.AppendLine(item.Content.Type);
                }
                
                _contentText.Text = text.ToString();

                _linkLabel.Text = item.Title.Text;
                _linkLabel.Tag = item;
            }
        }

        /// <summary>
        /// Abre un navegador web hacia la dirección URL del elemento del feed seleccionado
        /// en el árbol. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void OnLinkClicked(object sender, LinkLabelLinkClickedEventArgs args)
        {
            SyndicationItem item = _linkLabel.Tag as SyndicationItem;
            if (item != null && item.Links.Count() > 0)
                Process.Start(item.Links.First().Uri.ToString());
        }

        protected override void OnLoad(EventArgs args)
        {
            base.OnLoad(args);

            // Sólo nos aseguramos que haya una opción seleccionada por defecto,
            // en este caso, la opción de RSS. 
            _rssOptionsCombo.SelectedIndex = 0;
        }
    }
}
